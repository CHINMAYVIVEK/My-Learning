public class one {
   public static void main(String args[]) {
      // Prints "Chinmay Vivek" in the terminal window.
      System.out.println("Chinmay Vivek");
   }
}