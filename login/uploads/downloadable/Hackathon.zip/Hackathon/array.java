
//import package one.*;
// i+++i+++++i+++i++;



Class array
{
Static int i;
i = i+++i+++++i+++i++;
System.out.println(i);
}

