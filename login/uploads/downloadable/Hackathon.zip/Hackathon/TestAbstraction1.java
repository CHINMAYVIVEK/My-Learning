

abstract class diemention{
	abstract void area();  
	
}

class Rectangle extends diemention{
	void area(){
		System.out.println("Rectangle running safely..");
		}  
}

class Triangle extends diemention{
	void area(){
		System.out.println("Triangle running safely..");
		}  
	
}

class TestAbstraction1{  
public static void main(String args[]){  
diemention d=new Rectangle();
d.area();  
}  
}  
  
