    package mypack;  
    public class Test{  
    public static void main(String args[]){  
      
    Employee e=new Employee();//object is created  
      
    e.setName("Chinmay");//setting value to the object  
      
    System.out.println(e.getName());  
      
    }}  